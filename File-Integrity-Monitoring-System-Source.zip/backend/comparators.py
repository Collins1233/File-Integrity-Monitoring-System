import difflib
import base64
import hashlib
import mimetypes
import zipfile

from docx import Document
from openpyxl import load_workbook
from pptx import Presentation

try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None

try:
    from striprtf.striprtf import rtf_to_text
except ImportError:
    rtf_to_text = None

try:
    import xlrd
except ImportError:
    xlrd = None


def read_text_file(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return file.readlines()
    except UnicodeDecodeError:
        try:
            with open(file_path, "r", encoding="latin-1") as file:
                return file.readlines()
        except Exception:
            return []
    except Exception:
        return []


def compare_text(old_file, new_file):
    old_lines = read_text_file(old_file)
    new_lines = read_text_file(new_file)
    return list(
        difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile="Baseline Version",
            tofile="Current Version",
            lineterm="",
        )
    )


def _format_line_comparison(before_lines, after_lines, preview_type, document_type=None, extra=None):
    before = [line.rstrip("\n\r") if isinstance(line, str) else str(line) for line in before_lines]
    after = [line.rstrip("\n\r") if isinstance(line, str) else str(line) for line in after_lines]

    matcher = difflib.SequenceMatcher(None, before, after)
    changed_before = set()
    changed_after = set()

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        if tag in ("replace", "delete"):
            changed_before.update(range(i1, i2))
        if tag in ("replace", "insert"):
            changed_after.update(range(j1, j2))

    result = {
        "before": before,
        "after": after,
        "changed_before_lines": sorted(changed_before),
        "changed_after_lines": sorted(changed_after),
        "summary": {
            "lines_removed": len(changed_before),
            "lines_added": len(changed_after),
            "total_changes": len(changed_before) + len(changed_after),
        },
        "preview_type": preview_type,
    }
    if document_type:
        result["document_type"] = document_type
    if extra:
        result.update(extra)
    return result


def _collect_paragraph_lines(paragraphs, lines):
    for paragraph in paragraphs:
        text = (paragraph.text or "").strip()
        if text:
            lines.append(text)


def _collect_table_lines(tables, lines):
    for table in tables:
        for row in table.rows:
            cells = [(cell.text or "").strip() for cell in row.cells]
            cells = [cell for cell in cells if cell]
            if cells:
                lines.append(" | ".join(cells))


def _word_to_lines(file_path):
    """Extract readable text from a .docx for side-by-side comparison."""
    doc = Document(file_path)
    lines = []

    _collect_paragraph_lines(doc.paragraphs, lines)
    _collect_table_lines(doc.tables, lines)

    # Headers / footers often hold title or revision text users care about.
    for section in doc.sections:
        try:
            _collect_paragraph_lines(section.header.paragraphs, lines)
            _collect_table_lines(section.header.tables, lines)
            _collect_paragraph_lines(section.footer.paragraphs, lines)
            _collect_table_lines(section.footer.tables, lines)
        except Exception:
            continue

    if not lines:
        lines.append("(No readable text found in this Word document)")
    return lines


def compare_word(old_file, new_file):
    return list(
        difflib.unified_diff(
            _word_to_lines(old_file),
            _word_to_lines(new_file),
            fromfile="Baseline Version",
            tofile="Current Version",
            lineterm="",
        )
    )


def format_word_change(old_file, new_file):
    before = _word_to_lines(old_file)
    after = _word_to_lines(new_file)
    result = _format_line_comparison(before, after, "document", "word")
    return _attach_media_changes(result, old_file, new_file, "word/media/")


def _attach_media_changes(result: dict, old_file: str, new_file: str, media_prefix: str) -> dict:
    media = _compare_office_media(old_file, new_file, media_prefix)
    if not media["items"]:
        return result
    result["media_changes"] = media["items"]
    result["summary"]["media_added"] = media["added"]
    result["summary"]["media_removed"] = media["removed"]
    result["summary"]["media_replaced"] = media["replaced"]
    result["summary"]["total_changes"] = (
        result["summary"].get("total_changes", 0)
        + media["added"]
        + media["removed"]
        + media["replaced"]
    )
    if result["summary"].get("lines_removed", 0) == 0 and result["summary"].get("lines_added", 0) == 0:
        result["message"] = _media_change_message(media)
    elif not result.get("message"):
        result["message"] = _media_change_message(media)
    return result


_IMAGE_MEDIA_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".emf", ".wmf"}
_THUMBNAIL_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}
_MAX_THUMB_BYTES = 350_000


def _media_mime(name: str) -> str:
    mime, _ = mimetypes.guess_type(name)
    return mime or "application/octet-stream"


def _office_media_inventory(file_path: str, media_prefix: str) -> dict:
    """Map content-hash -> list of media entries inside an Office zip package."""
    inventory = {}
    try:
        with zipfile.ZipFile(file_path, "r") as archive:
            for name in archive.namelist():
                if not name.startswith(media_prefix) or name.endswith("/"):
                    continue
                basename = name.rsplit("/", 1)[-1]
                if not basename or basename.startswith("."):
                    continue
                extension = ("." + basename.rsplit(".", 1)[-1].lower()) if "." in basename else ""
                if extension and extension not in _IMAGE_MEDIA_EXTS and not extension.startswith("."):
                    continue
                # Include common image types; skip huge non-image binaries by extension filter
                if extension and extension not in _IMAGE_MEDIA_EXTS:
                    continue
                data = archive.read(name)
                digest = hashlib.sha256(data).hexdigest()
                entry = {
                    "name": basename,
                    "path": name,
                    "hash": digest,
                    "size": len(data),
                    "extension": extension,
                }
                if extension in _THUMBNAIL_EXTS and len(data) <= _MAX_THUMB_BYTES:
                    entry["thumbnail"] = (
                        f"data:{_media_mime(basename)};base64,{base64.b64encode(data).decode('ascii')}"
                    )
                inventory.setdefault(digest, []).append(entry)
    except (OSError, zipfile.BadZipFile):
        return {}
    return inventory


def _flatten_media(inventory: dict) -> list:
    items = []
    for entries in inventory.values():
        items.extend(entries)
    return sorted(items, key=lambda item: item["name"].lower())


def _compare_office_media(old_file: str, new_file: str, media_prefix: str) -> dict:
    old_inv = _office_media_inventory(old_file, media_prefix)
    new_inv = _office_media_inventory(new_file, media_prefix)

    old_hashes = set(old_inv)
    new_hashes = set(new_inv)
    common = old_hashes & new_hashes
    only_old = old_hashes - new_hashes
    only_new = new_hashes - old_hashes

    items = []
    for digest in sorted(only_old):
        for entry in old_inv[digest]:
            items.append({
                "change": "removed",
                "label": f"Image removed: {entry['name']}",
                "name": entry["name"],
                "before": entry,
                "after": None,
            })
    for digest in sorted(only_new):
        for entry in new_inv[digest]:
            items.append({
                "change": "added",
                "label": f"Image added: {entry['name']}",
                "name": entry["name"],
                "before": None,
                "after": entry,
            })

    # Same filename, different content → replaced
    old_by_name = {e["name"]: e for e in _flatten_media(old_inv)}
    new_by_name = {e["name"]: e for e in _flatten_media(new_inv)}
    for name in sorted(set(old_by_name) & set(new_by_name)):
        old_entry = old_by_name[name]
        new_entry = new_by_name[name]
        if old_entry["hash"] == new_entry["hash"]:
            continue
        # Prefer a single "replaced" card for same filename
        items = [
            item for item in items
            if not (
                (item["change"] == "removed" and item["name"] == name)
                or (item["change"] == "added" and item["name"] == name)
            )
        ]
        items.append({
            "change": "replaced",
            "label": f"Image replaced: {name}",
            "name": name,
            "before": old_entry,
            "after": new_entry,
        })

    added = sum(1 for item in items if item["change"] == "added")
    removed = sum(1 for item in items if item["change"] == "removed")
    replaced = sum(1 for item in items if item["change"] == "replaced")
    return {
        "items": items,
        "added": added,
        "removed": removed,
        "replaced": replaced,
        "unchanged": len(common),
    }


def _media_change_message(media: dict) -> str:
    parts = []
    if media["added"]:
        parts.append(f"{media['added']} image{'s' if media['added'] != 1 else ''} added")
    if media["removed"]:
        parts.append(f"{media['removed']} image{'s' if media['removed'] != 1 else ''} removed")
    if media["replaced"]:
        parts.append(f"{media['replaced']} image{'s' if media['replaced'] != 1 else ''} replaced")
    if not parts:
        return "Embedded media changed in this document."
    return "Embedded images changed: " + ", ".join(parts) + "."


def _excel_cell_changes(old_book, new_book):
    changes = []
    all_sheets = set(old_book.sheetnames) | set(new_book.sheetnames)

    for sheet_name in sorted(all_sheets):
        if sheet_name not in old_book.sheetnames:
            changes.append({
                "sheet": sheet_name,
                "cell": "(none)",
                "before": "(sheet did not exist)",
                "after": "(new sheet added)",
            })
            continue
        if sheet_name not in new_book.sheetnames:
            changes.append({
                "sheet": sheet_name,
                "cell": "(none)",
                "before": "(sheet existed)",
                "after": "(sheet removed)",
            })
            continue

        old_sheet = old_book[sheet_name]
        new_sheet = new_book[sheet_name]
        rows = max(old_sheet.max_row or 1, new_sheet.max_row or 1)
        cols = max(old_sheet.max_column or 1, new_sheet.max_column or 1)

        for row in range(1, rows + 1):
            for col in range(1, cols + 1):
                old_value = old_sheet.cell(row, col).value
                new_value = new_sheet.cell(row, col).value
                if old_value != new_value:
                    cell = old_sheet.cell(row, col).coordinate
                    changes.append({
                        "sheet": sheet_name,
                        "cell": cell,
                        "before": "" if old_value is None else str(old_value),
                        "after": "" if new_value is None else str(new_value),
                    })
    return changes


def _excel_to_lines(workbook):
    lines = []
    for sheet_name in workbook.sheetnames:
        sheet = workbook[sheet_name]
        lines.append(f"── Sheet: {sheet_name} ──")
        max_row = sheet.max_row or 1
        max_col = sheet.max_column or 1
        for row in range(1, max_row + 1):
            for col in range(1, max_col + 1):
                value = sheet.cell(row, col).value
                if value is not None and str(value).strip():
                    coord = sheet.cell(row, col).coordinate
                    lines.append(f"{coord}: {value}")
        if max_row == 1 and max_col == 1 and sheet.cell(1, 1).value in (None, ""):
            lines.append("(empty sheet)")
    return lines


def compare_excel(old_file, new_file):
    old_book = load_workbook(old_file, data_only=True)
    new_book = load_workbook(new_file, data_only=True)
    return [
        f"{item['sheet']} | {item['cell']} | {item['before']} → {item['after']}"
        for item in _excel_cell_changes(old_book, new_book)
    ]


def format_excel_change(old_file, new_file):
    old_book = load_workbook(old_file, data_only=True)
    new_book = load_workbook(new_file, data_only=True)
    cell_changes = _excel_cell_changes(old_book, new_book)
    result = _format_line_comparison(
        _excel_to_lines(old_book),
        _excel_to_lines(new_book),
        "spreadsheet",
        "excel",
        {"cell_changes": cell_changes},
    )
    result["summary"] = {
        "lines_removed": len(cell_changes),
        "lines_added": len(cell_changes),
        "total_changes": len(cell_changes),
        "cells_changed": len(cell_changes),
    }
    return result


def extract_slide_text(slide):
    text = []
    for shape in slide.shapes:
        if hasattr(shape, "text") and shape.text.strip():
            text.append(shape.text.strip())
    return text


def _ppt_to_lines(file_path):
    presentation = Presentation(file_path)
    lines = []
    for index, slide in enumerate(presentation.slides, start=1):
        slide_text = extract_slide_text(slide)
        if slide_text:
            lines.append(f"── Slide {index} ──")
            lines.extend(slide_text)
    return lines


def compare_powerpoint(old_file, new_file):
    differences = []
    old_ppt = Presentation(old_file)
    new_ppt = Presentation(new_file)
    total = max(len(old_ppt.slides), len(new_ppt.slides))

    for index in range(total):
        if index >= len(old_ppt.slides):
            differences.append(f"[NEW SLIDE] {index + 1}")
            continue
        if index >= len(new_ppt.slides):
            differences.append(f"[DELETED SLIDE] {index + 1}")
            continue

        diff = list(
            difflib.unified_diff(
                extract_slide_text(old_ppt.slides[index]),
                extract_slide_text(new_ppt.slides[index]),
                fromfile=f"Slide {index + 1}",
                tofile=f"Slide {index + 1}",
                lineterm="",
            )
        )
        differences.extend(diff)
    return differences


def format_ppt_change(old_file, new_file):
    before = _ppt_to_lines(old_file)
    after = _ppt_to_lines(new_file)
    result = _format_line_comparison(before, after, "presentation", "powerpoint")
    return _attach_media_changes(result, old_file, new_file, "ppt/media/")


def _pdf_to_lines(file_path):
    if PdfReader is None:
        return ["(Install pypdf to preview PDF text)"]
    lines = []
    reader = PdfReader(file_path)
    for index, page in enumerate(reader.pages, start=1):
        text = (page.extract_text() or "").strip()
        if text:
            lines.append(f"── Page {index} ──")
            lines.extend(line for line in text.splitlines() if line.strip())
    if not lines:
        lines.append("(No extractable text in this PDF. It may be image based or scanned)")
    return lines


def format_pdf_change(old_file, new_file):
    before = _pdf_to_lines(old_file)
    after = _pdf_to_lines(new_file)
    return _format_line_comparison(before, after, "document", "pdf")


def _rtf_to_lines(file_path):
    if rtf_to_text is None:
        return ["(Install striprtf to preview RTF content)"]
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as handle:
            raw = handle.read()
        text = rtf_to_text(raw)
        return [line for line in text.splitlines() if line.strip()]
    except Exception:
        return []


def format_rtf_change(old_file, new_file):
    before = _rtf_to_lines(old_file)
    after = _rtf_to_lines(new_file)
    return _format_line_comparison(before, after, "document", "rtf")


def _xls_to_lines(file_path):
    if xlrd is None:
        return ["(Install xlrd to preview legacy .xls files)"]
    lines = []
    book = xlrd.open_workbook(file_path)
    for sheet in book.sheets():
        lines.append(f"── Sheet: {sheet.name} ──")
        for row_index in range(sheet.nrows):
            for col_index in range(sheet.ncols):
                value = sheet.cell_value(row_index, col_index)
                if value not in (None, ""):
                    col_letter = xlrd.colname(col_index)
                    lines.append(f"{col_letter}{row_index + 1}: {value}")
    return lines


def format_xls_change(old_file, new_file):
    before = _xls_to_lines(old_file)
    after = _xls_to_lines(new_file)
    return _format_line_comparison(before, after, "spreadsheet", "excel")


def format_office_change(old_file, new_file, extension):
    if extension == ".docx":
        return format_word_change(old_file, new_file)
    if extension == ".xlsx":
        return format_excel_change(old_file, new_file)
    if extension == ".pptx":
        return format_ppt_change(old_file, new_file)
    if extension == ".pdf":
        return format_pdf_change(old_file, new_file)
    if extension == ".rtf":
        return format_rtf_change(old_file, new_file)
    if extension == ".xls":
        return format_xls_change(old_file, new_file)
    return None


def extract_office_text(file_path, extension):
    """Readable text preview for document-like files."""
    if extension == ".docx":
        return "\n".join(_word_to_lines(file_path))
    if extension == ".xlsx":
        return "\n".join(_excel_to_lines(load_workbook(file_path, data_only=True)))
    if extension == ".pptx":
        return "\n".join(_ppt_to_lines(file_path))
    if extension == ".pdf":
        return "\n".join(_pdf_to_lines(file_path))
    if extension == ".rtf":
        return "\n".join(_rtf_to_lines(file_path))
    if extension == ".xls":
        return "\n".join(_xls_to_lines(file_path))
    return None
